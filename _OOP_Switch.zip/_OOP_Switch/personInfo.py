# -*- coding: utf-8 -*-
"""
Created on Thu Dec 31 20:55:24 2020

@author: Pallavi
"""

class Person():
    pcount=0
    def __init__(self,name,age,mobNo):
        self.name=name
        self.age=age
        self.mobNo=mobNo
        Person.pcount+=1

#    if we define this method than 
#    no need to write the display method and no need to call that method

    def __str__(self):
        return "\nName: "+self.name+"\nAge : "+str(self.age)+"\nMobile: "+str(self.mobNo)

#    def pdisplay(self):
#       print("\n Name: ",self.name,"\n Age: ",self.age,"\n MObile no: ",self.mobNo)
      
  
#    def countShow():
#        print("Total Person: %d" %Person.pcount)
        
# Setter method to change values
    def setname(self,name):
        self.name=name
    def setage(self,age):
        self.age=age
    def setmobNo(self,mobNo):
        self.mobNo=mobNo
        
# Getter method to retrieve values
    def getname(self):
        return self.name
    def getid(self):
        return self.age
    def getmobNo(self):
        return self
        
p=Person("Pallavi",25,90909090)
# q=Person("Lokesh",30,999990000)
# p.pdisplay()                    
# q.pdisplay()
# Person.countShow()
print("Total Person: ",Person.pcount)        
