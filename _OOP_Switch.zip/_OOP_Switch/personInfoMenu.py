# -*- coding: utf-8 -*-
"""
Created on Fri Jan  1 23:41:39 2021

@author: Pallavi
"""
import sys
from personInfo import Person
from personInfoMenuFunction import *

plist=[]
#plist=["pop",12,58959]
#print(plist)
choice=0
while choice!=6:
    print("1.Add Person")
    print("2.Delete Person")
    print("3.Modifify Person")
    print("4.Display all Person")
    print("5.Search by Name")
    print("6.Exit")
    
    choice=int(input("Enter your choice: "))
    if choice == 1:
        addPerson(plist)
        
    elif choice ==2:
        name=input("Enter Name: ")
        ans=deletePerson(name,plist)
        if ans==True:
            print("Deleted Successfully ! ")
        else:
            print("Not Found ! ")
            
    elif choice==3:
        name=input("Enter Name: ")
        mobNo=int(input("Enter MObile No.: "))
        ans=modifyPerson(name,mobNo,plist)
        if ans==True:
            print("Updated successfully")
        else:
            print("Not Found")   

    elif choice==4:
        displayPerson(plist)
    
    elif choice ==5:
        name=input("Enter name for search: ")
        pos=searchByName(name,plist)
        if pos!=-1:
            print(plist[pos])
        else:
            print("Person not found")
        
    else:
        sys.exit()
        