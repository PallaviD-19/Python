# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 22:05:19 2021

@author: Pallavi
"""


from personInfo import *
#from personInfoMenu import *
plist=[]

def addPerson(plist):
    name=input("Enter Name: ")
#    age=int(input("Enter Age: "))
    age=input("Enter Age: ")
    mobNo=int(input("Enter Mobile Number: "))
    q=Person(name,age,mobNo)
    plist.append(q)
    print(plist)

def displayPerson(plist):
    for q in plist:
        print(q)
        print("------------------------")

def searchByName(name,plist):
    count=0
    for q in plist:
        if q.getname()==name:
            return count
        count+=1
    else:
        return -1    
    
def deletePerson(name,plist):
    pos=searchByName(name,plist)
    if pos!=-1:
        print(plist[pos])
        ans=input("Delete (y/n) ? ")
        if ans=="y":
            plist.pop(pos)
            return True
    else:
        return False

def modifyPerson(name,mobNo,plist):
    pos=searchByName(name,plist)
    if pos!=-1:
        plist[pos].setmobNo(mobNo)
        return True
    else:
        return False

    
    
    
    